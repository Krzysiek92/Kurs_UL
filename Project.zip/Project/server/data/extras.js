module.exports = [
    {
        id: 1,
        label: 'Sok pomarańczowy 1l',
        price: 4.99
    }, {
        id: 2,
        label: 'Sok jabłkowy 1l',
        price: 4.99
    }, {
        id: 3,
        label: 'Sok multiwitamin 1l',
        price: 4.99
    }, {
        id: 4,
        label: 'Sos pomidorowy',
        price: 1.99
    }, {
        id: 4,
        label: 'Sos pomidorowy ostry',
        price: 1.99
    }, {
        id: 4,
        label: 'Sos czosnkowy',
        price: 1.99
    }
];
